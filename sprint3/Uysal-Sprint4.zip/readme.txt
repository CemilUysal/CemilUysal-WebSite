16050111006
Cemil Uysal
url: http://cemiluysal.herokuapp.com/sprint3/series_page/series.html
note: I changed the url of the web site so sprint3 url was broken.
Using Plugins:
	In the Timeline page back to top.
	In the Books page back to top and responsive slider.
	In the Movies page back to top, responsive slider and rating star.
	In the Series page back top top, responsive slider and rating star.
Using UI:
	In the every page autocomplate.
	In the Series page toggle comment. While rating star was clicking
      comment line was open.  
